import numpy as np
import math
import matplotlib.pyplot as plt
from PIL import Image
import torchvision
import torch
from math import atan2,pi

import itertools
import os
import cleardata 
import shapedatagauss
import shapfracdata
'''
wigth: 图像大小
r    : 图形尺度
maskflag: 噪声标志
num  : 纹理密度
model: 图形纹理
f    : 分型特征
'''

def getcircle(wigth,r,maskflag,num,model,f):
    '''
    生成各种圆
    1：无纹理圆
    2：条形纹理
    3：分型纹理
    '''
    fractal2 = np.load("circle.npy")  # 圆
    fractal3 = np.load("triange.npy")  # 三角
    fractal4 = np.load("squaretan.npy")  # 方
    #是否加入噪声
    if maskflag == 0:        
        mask = np.random.normal(size=(224, 224), scale=0, loc=1)
    elif maskflag==1:
        mask = np.random.normal(size=(224, 224), scale=0.2, loc=0)

    if model == 1:
        img = cleardata.unit_circle(wigth, r, mask)
    elif model==2:
        img = shapedatagauss.unit_circle(wigth, r, mask, num)
    elif model==3:
        img = shapfracdata.unit_circle(wigth, r, mask, num)
        if f==1:
            img = np.multiply(fractal2, img)
        elif f==2:
            img = np.multiply(fractal3, img)
        elif f==3:
            img = np.multiply(fractal4, img)
    return img

def getsquare(wigth,r,maskflag,num,model,f):
    '''
    生成各种方
    1：无纹理方
    2：条形纹理
    3：分型纹理
    '''
    fractal2 = np.load("circle.npy")  # 圆
    fractal3 = np.load("triange.npy")  # 三角
    fractal4 = np.load("squaretan.npy")  # 方
    if maskflag == 0:        
        mask = np.random.normal(size=(224, 224), scale=0, loc=1)
    elif maskflag==1:
        mask = np.random.normal(size=(224, 224), scale=0.2, loc=0)
    if model == 1:
        img = cleardata.unit_square(wigth, r, mask)
    elif model==2:
        img = shapedatagauss.unit_square(wigth, r, mask, num)
    elif model==3:
        img = shapfracdata.unit_square(wigth, r, mask, num)
        # img = np.multiply(fractal2, img)
        if f==1:
            img = np.multiply(fractal2, img)
        elif f==2:
            img = np.multiply(fractal3, img)
        elif f==3:
            img = np.multiply(fractal4, img)

    return img


def gettriangle(wigth,r,maskflag,num,model,f):
    '''
    生成各种三角
    1：无纹理三角
    2：条形纹理
    3：分型纹理
    '''
    fractal2 = np.load("circle.npy")  # 圆
    fractal3 = np.load("triange.npy")  # 三角
    fractal4 = np.load("squaretan.npy")  # 方
    if maskflag == 0:        
        mask = np.random.normal(size=(224, 224), scale=0, loc=1)
    elif maskflag==1:
        mask = np.random.normal(size=(224, 224), scale=0.2, loc=0)
    if model == 1:
        img = cleardata.unit_triangle(wigth, r, mask)
    elif model==2:
        img = shapedatagauss.unit_triangle(wigth, r, mask, num)
    elif model==3:
        img = shapfracdata.unit_triangle(wigth, r, mask, num)
        # img = np.multiply(fractal2, img)
        if f==1:
            img = np.multiply(fractal2, img)
        elif f==2:
            img = np.multiply(fractal3, img)
        elif f==3:
            img = np.multiply(fractal4, img)
    return img



if __name__ == "__main__":
    # getcircle(wigth,r,maskflag,num,model,f)
    '''
    wigth: 图像大小
    r    : 图形尺度
    maskflag: 噪声标志
    num  : 纹理密度
    model: 图形纹理
    f    : 分型特征
    '''
    for r in [80,60,40]:
        for maskflag in [0,1]:
            for model in [1, 2, 3]:
                f = 1
                img = getcircle(224,r,maskflag,4,model,f)
                Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').save(str(r)+str(maskflag)+str(model)+'circle'+'.png')
                img = getsquare(224,r,maskflag,4,model,f)
                Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').save(str(r)+str(maskflag)+str(model)+'square'+'.png')
                img = gettriangle(224,r,maskflag,4,model,f)
                Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').save(str(r)+str(maskflag)+str(model)+'triangle'+'.png')
