import numpy as np
import math
import matplotlib.pyplot as plt
from PIL import Image
import torchvision
import torch
from math import atan2,pi

import itertools
import os
def unit_circle(d,r,mask):
    '''
    生成圆形
    d:图像边长
    r:蒙色直径
    '''
    def distance(x1, y1, x2, y2):
        return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
    mat1 = np.zeros((d, d))
    mat2 = np.zeros((d, d))
    # mask = np.random.normal(size=(d,d), scale=scale, loc=loc) #loc表示均值，scale表示方差，size表示输出的size
    rx , ry = int(d/2), int(d/2)
    for row in range(d):
        for col in range(d):
            dist = distance(rx, ry, row, col)
            # print((row,col),dist)
            if abs(dist) < r:
                mat1[row, col] = 1
            # #黑白相间条纹
            # if row%20>16:
            #     # print(row,row/20)
            #     mat2[row, col] = 1

    finalmat = np.multiply(mat1,mask)
    # finalmat = np.multiply(mat2,finalmat)
    # plt.imsave('testcircle.png',finalmat)
    # Image.fromarray((finalmat * 255).astype('uint8'), mode='L').convert('RGB').save('testcircle.png')
    return finalmat
def circshift(matrix,shiftnum1,shiftnum2):
    #矩阵循环移位
    #hstack是水平分割，用在列数的移动；vstack是垂直分割，用于行数的移动。
    h,w=matrix.shape
    matrix=np.vstack((matrix[(h-shiftnum1):,:],matrix[:(h-shiftnum1),:]))
    matrix=np.hstack((matrix[:,(w-shiftnum2):],matrix[:,:(w-shiftnum2)]))
    return matrix
def unit_square(d,r,mask):
    '''
    生成正方形
    d:图像边长
    r:蒙色直径
    '''
    def distance(x1, y1, x2, y2):
        return abs(x1 - x2)
    mat1 = np.zeros((d, d))
    mat2 = np.zeros((d, d))
    # mask = np.random.normal(size=(d,d), scale=scale, loc=loc) #loc表示均值，scale表示方差，size表示输出的size
    rx , ry = int(d/2), int(d/2)
    for row in range(d):
        for col in range(d):
            # dist = distance(rx, ry, row, col)
            # print((row,col),dist)
            if abs(row-rx) < r and abs(col-ry) < r:
                mat1[row, col] = 1
            # if row%20>16:
            #     # print(row,row/20)
            #     mat2[row, col] = 1

    finalmat = np.multiply(mat1,mask)
    # finalmat = np.multiply(mat2,finalmat)
    # plt.imsave('testsquare.png',finalmat)
    # Image.fromarray((finalmat * 255).astype('uint8'), mode='L').convert('RGB').save('testsquare.png')
    return finalmat
def unit_triangle(d,r,mask):
    '''
    生成等边三角形
    d:图像边长
    r:蒙色直径
    '''
    mat1 = np.zeros((d, d))
    mat2 = np.zeros((d, d))
    # mask = np.random.normal(size=(d,d), scale=scale, loc=loc) #loc表示均值，scale表示方差，size表示输出的size
    # d = 2*r
    for i in range(d):
        for j in range(d):
            if atan2(j, i) < pi / 3 and atan2(0 - j, d - i) > -pi / 3 and j>(d*80)//(5*r):
                mat1[i, j] = 1
            # if (i)%20>14:
            #     mat2[i, d//2-(i-(d-r)//2+1)+j] = 1
    # 渐变黑白高斯纹理
    # mat2 = unit_gauss(d)
    
    mat1 = unit_rot(mat1)
    mat1 = circshift(mat1,80-r,0)
    finalmat = np.multiply(mat1,mask)
    # finalmat = np.multiply(mat2,finalmat)
    # Image.fromarray((finalmat * 255).astype('uint8'), mode='L').convert('RGB').save('testangle.png')
    return finalmat

def unit_rot(data):
    # newdata45 = pcolormesh_45deg(data)
    newadta90 = np.rot90(data)
    # Image.fromarray((newdata45 * 255).astype('uint8'), mode='L').convert('RGB').save('testtor45.png')

    # Image.fromarray((newadta90 * 255).astype('uint8'), mode='L').convert('RGB').save('testtor90.png')
    return newadta90


def Generateimage(numslice,classfic):
    dcm = np.zeros((numslice,512,512))
    dis = int(400/numslice)
    r = 0.
    i = 1
    for dic in range(numslice):
        r += dis   
        if r>200:            
            disr = r    
            disr = disr-dis*(2*i-1)
            dcm[dic,:,:] = unit_circle(512,disr,classfic)
            i += 1
        else:
            disr = r
            dcm[dic,:,:] = unit_circle(512,disr,classfic)
    dcm = dcm.reshape(16,1,512,512)
    dcm = torch.from_numpy(dcm)
    img = torchvision.utils.make_grid(dcm,nrow=4,normalize=True)
    img = img.numpy().transpose((1,2,0))
    # plt.imsave('test.png',img)
    Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').save('test.png')
    print('max:',torch.max(dcm))
    # plt.imsave('test.png',finalmat)
    return dcm
def Generations(number):
    # classnum = int(number/5)
    y = []
    x = []
    for index in range(number):
        classfic = index%5 +1
        dcm = Generateimage(16,classfic)  #==>(16, 1, 512, 512)
        dcm = dcm.reshape(16,512,512)     #==>(16, 512, 512)
        x.append(dcm)                     #==>(100, 16, 512, 512)
        y.append(classfic-1)                #==>(100,1)
    return x, y

def ImageMosaic(CTimage):
    newimage = np.reshape(CTimage,(4,4,512,512))
    newimage = newimage.numpy().transpose((0,2,1,3))
    newimage1 = np.reshape(newimage,(2048,4,512))
    finalimage = np.reshape(newimage1,(2048,2048))
    # plt.imsave('test.png', finalimage)
    return finalimage


if __name__ == "__main__":
    # x, y = Generations(3000)
    # torch.save(x,'datax.npy')
    # torch.save(y,'datay.npy')
    # print(mat)
    #生成不同尺度的噪声图像和无噪声图像
    #clear,无噪声图像，noise噪声图像
    
    for r in [80,60,40]:

        mask = np.random.normal(size=(224, 224), scale=0.2, loc=0)
        # mask = (mask+np.max(mask))/(np.max(mask)-np.min(mask))
        image_circle = unit_circle(224, r, mask)
        # image_rot_circle = unit_rot(image_circle)
        image_square = unit_square(224, r, mask)
        # image_rot_square = unit_rot(image_square)
        image_tangle = unit_triangle(224, r, mask)
        # image_rot_tangle = unit_rot(image_tangle)

        Image.fromarray((image_circle * 255).astype('uint8'), mode='L').convert('RGB').save('noise'+str(r)+'testcircle.png')
        Image.fromarray((image_square * 255).astype('uint8'), mode='L').convert('RGB').save('noise'+str(r)+'testsquare.png')
        Image.fromarray((image_tangle * 255).astype('uint8'), mode='L').convert('RGB').save('noise'+str(r)+'testangle.png')
        # Image.fromarray((image_circle * 255).astype('uint8'), mode='L').convert('RGB').save('clear'+str(r)+'testcircle.png')
        # Image.fromarray((image_square * 255).astype('uint8'), mode='L').convert('RGB').save('clear'+str(r)+'testsquare.png')
        # Image.fromarray((image_tangle * 255).astype('uint8'), mode='L').convert('RGB').save('clear'+str(r)+'testangle.png')
        # Image.fromarray((image_rot_circle * 255).astype('uint8'), mode='L').convert('RGB').save('clear'+str(r)+'testcircle90.png')
        # Image.fromarray((image_rot_square * 255).astype('uint8'), mode='L').convert('RGB').save('clear'+str(r)+'testsquare90.png')
        # Image.fromarray((image_rot_tangle * 255).astype('uint8'), mode='L').convert('RGB').save('clear'+str(r)+'testtangle90.png')

