import os
os.system("python experimentall.py 1>>experimentall.log")
os.system("python experimentall_n.py 1>>experimentall_n.log")
