#噪声实验
#  Pytorch 0.4.0 VGG16实现cifar10分类.  
# @Time: 2018/6/23
# @Author: xfLi
'''
本程序实现生成测试矩阵（图像），来测试网络的可行性
测试数据尺寸：224*224
bathsize:20
输入图像只含有形状数据和噪声数据
'''
#前三行解决自定义包报错问题

import sys,os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # __file__获取执行文件相对路径，整行为取上一级的上一级目录
sys.path.append(BASE_DIR)
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import torch
import torch.nn as nn
import numpy as np
# from tensorboardX import SummaryWriter
# from timeplot import epochplt
import cv2
from torchvision import datasets,transforms, models
import torchvision
import modelnet
# from plugin.processplugin import Generations
from torch.autograd import Variable
import random
from cleardata import *
import matplotlib.pyplot as plt
from brokenaxes import brokenaxes
from testallnet import pltroc_auc
from sklearn.preprocessing import label_binarize
from sklearn.metrics import roc_curve, auc
# model_path = './model_pth/vgg16_bn-6c64b313.pth'
from PIL import Image
import getallshape
import random
from cleardata import circshift
import time

def _next_batch(batch_size, index_in_epoch):
    start = index_in_epoch
    index_in_epoch += batch_size
    # num_examples = train_labels.__len__()
    train_images = []
    # rotIdex = False
    noise = [1] #无噪声
    featuremodel = [1,2,3]
    texturemodel = [1]
    # when all trainig data have been already used, it is reorder randomly
    # if index_in_epoch > num_examples:
    #     start = 0
    #     index_in_epoch = batch_size
    #     assert batch_size <= num_examples
    # end = index_in_epoch
    # labels = train_labels[start:end]
    newlabels = []
    '''
    wigth: 图像大小
    r    : 图形尺度
    maskflag: 噪声标志
    num  : 纹理密度
    model: 图形纹理
    f    : 分型特征
    '''
    # for i in labels:
    #     if i==0:
    #         img = getallshape.getsquare(224,80,1,4,3,1)
    #         Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').save('/media/liqiang/windata/project/classification/plugin/tempictures/'+'exp120'+'circle_c.png')
    #     elif i==1:
    #         img = getallshape.getsquare(224,60,1,4,1,1)
    #         Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').save('/media/liqiang/windata/project/classification/plugin/tempictures/'+'exp120'+'circle_g.png')
    #     elif i==2:
    #         img = getallshape.getsquare(224,40,1,4,2,1)
    #         Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').save('/media/liqiang/windata/project/classification/plugin/tempictures/'+'exp120'+'circle_f.png')
    #     train_images.append(img)
    #     newlabels.append(i)
    #     if rotIdex:
    #         img = unit_rot(img)
    #         train_images.append(img)
    #         newlabels.append(i)    
    i = 0 
    # shif1 = random.randint(-20,20)
    # shif2 = random.randint(-20,20)
    # rot1   = random.randint(0,360)
    # rot2   = random.randint(0,360)
    # rot3   = random.randint(0,360)
    for r in [80, 60, 40]:
        for maskflag in noise:
            for texture in texturemodel:
                for feature in featuremodel:
                    shif1 = random.randint(-10,10)
                    shif2 = random.randint(-10,10)
                    rot1   = random.randint(0,360)
                    rot2   = random.randint(0,360)
                    rot3   = random.randint(0,360)
                    img = getallshape.getcircle(224,r,maskflag,4,feature,texture)
                    img = circshift(img,80-r-shif1,shif2)
                    Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').rotate(rot1).save('allfeaturepics/'+str(r)+str(texture)+str(feature)+'circle_n.png')
                    train_images.append(img)  
                    newlabels.append(i)
                    i += 1 
                    img = getallshape.gettriangle(224,r,maskflag,4,feature,texture)
                    img = circshift(img,80-r-shif1,shif2)
                    Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').rotate(rot2).save('allfeaturepics/'+str(r)+str(texture)+str(feature)+'triangle_n.png')
                    train_images.append(img)  
                    newlabels.append(i)
                    i += 1 
                    img = getallshape.getsquare(224,r,maskflag,4,feature,texture)
                    img = circshift(img,80-r-shif1,shif2)
                    Image.fromarray((img * 255).astype('uint8'), mode='L').convert('RGB').rotate(rot3).save('allfeaturepics/'+str(r)+str(texture)+str(feature)+'square_n.png')
                    train_images.append(img)  
                    newlabels.append(i)
                    i += 1 
    return train_images, newlabels, index_in_epoch


def Scramdata(train_x, train_y):
    """
    Scrambling data order
    :param data:
    :return:
    """
    data_num = len(train_x)
    data_idex = [i for i in range(data_num)]
    random.shuffle(data_idex)
    newtrain_x = [train_x[idx] for idx in data_idex]
    newtrain_y = [train_y[idx] for idx in data_idex]
    return newtrain_x, newtrain_y
def pltROC(netlist, Alllabels, Allprelabels):
    # for i in range(len(netlist)):
        fpr = dict()
        tpr = dict()
        roc_auc = dict()
        for j in range(27):
            plt.figure()
            for i in range(len(netlist)):
                fpr[j], tpr[j], _ = roc_curve(Alllabels[i][:, j], Allprelabels[i][:, j])
                roc_auc[j] = auc(fpr[j], tpr[j])
                fpr["micro"], tpr["micro"], _ = roc_curve(Alllabels[i].ravel(), Allprelabels[i].ravel())
                roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
                lw = 2
                plt.plot(fpr[j], tpr[j],
                        lw=lw, label=netlist[i]+'(area = %0.4f)' % roc_auc[j])

        # for k in range(27):
        #     # Compute micro-average ROC curve and ROC area
        #     fpr["micro"], tpr["micro"], _ = roc_curve(Alllabels[i].ravel(), Allprelabels[i].ravel())
        #     roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
        #     lw = 2
        #     plt.plot(fpr[k], tpr[k],
        #             lw=lw, label='E'+str(k)+'_'+netlist[i]+'(area = %0.4f)' % roc_auc[k])
            plt.plot([0, 1], [0, 1], lw=2, linestyle='--')
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title('Receiver operating characteristic example')
            plt.legend(loc="lower right")
            plt.savefig(os.path.join('ROC_AUC_FIG','E_n'+str(j)+"_roc.jpg"))

def train():
    # net = alexnet()
    # print(net)
    # use_gpu = True
    
    # if use_gpu:
    #     net = net.cuda()
    # x, y = Generations(200)
     
    torch_device = torch.device('cuda')

    # train_x, train_y, test_x, test_y, val_x, val_y = getData()
    #load net
    layer = 1   #channels
    use_gpu = True #是否使用gpu
    pretrained = False #是否使用与训练模型
    batch_size = 27

    netlist = ['MobileNet','ResNet','ShuffleNet','SqueezeNet','AlexNet','DenseNet','GoogleNet','MnasNet','VggNet']
    # netlist = ['mobilenet','resnet','shufflenet','squeezenet','alexnet','densenet','googlenet','mnastnet']
    # netlist = ['mobilenet','resnet','vgg16']
    # netlist = ['GoogleNet']
    Allacc = []
    Alllos = []
    Alllabels = []
    Allprelabels = []
    val_Allacc = []
    val_Alllos = []
    test_Allacc = []
    test_Alllos = []
    test_all_labels = []
    test_all_label = []
    test_all_pres = []
    test_Accuracy_list = []
    for netname in netlist:
        time_start = time.time()
        if netname=='MobileNet':
            net = modelnet.mobilenet(layer,use_gpu,pretrained)
        elif netname=='ResNet':
            net = modelnet.resnet(layer,use_gpu,pretrained)
        elif netname=='ShuffleNet':
            net = modelnet.shufflenet(layer,use_gpu,pretrained)
        elif netname=='SqueezeNet':
            net = modelnet.squeezenet(layer,use_gpu,pretrained)
        elif netname=='AlexNet':
            net = modelnet.alexnet(layer,use_gpu,pretrained)
        elif netname=='DenseNet':
            net = modelnet.densenet(layer,use_gpu,pretrained)
        elif netname=='GoogleNet':
            net = modelnet.googlenet(layer,use_gpu,pretrained)
        elif netname=='MnasNet':
            net = modelnet.mnasnet(layer,use_gpu,pretrained)
        elif netname=='VggNet':
            net = modelnet.vgg16(layer,use_gpu,pretrained)
        # print(netname)
        print(net)
        # Loss and Optimizer
        criterion = torch.nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(net.parameters(),lr=1e-3)
        # optimizer = torch.optim.Adam(net.classifier.parameters())
        # Train the model
        # y0 = np.zeros(2700,dtype=np.int)
        # y1 = np.ones(2700, dtype=np.int)
        # y2 = np.ones(2700, dtype=np.int)*2
        # y_label = np.concatenate((y0,y1,y2),axis=0)
        
        ##生成测试图像
        maxacc = []
        Accuracy_list = []
        Loss_list     = []
        val_Accuracy_list = []
        val_Loss_list     = []
        
        test_Loss_list     = []
        tempacc = 0

        for epoch in range(1):
            # optimizer = torch.optim.Adam(net.parameters())
            #打乱数据和标签
            # num = random.randint(1,2000)
            # random.seed(num)
            # random.shuffle(y_label)
            index_in_epoch = 0
            running_loss = 0.0
            running_correct = 0
            batch = 0
            newprelabels = []
            newtrulabels = []
            for iters in range(1000):
                batch += 1
                batch_x, batch_y, index_in_epoch = _next_batch(batch_size, index_in_epoch)
                # for step, (inputs, labels) in enumerate(trainset_loader):
                # batch_xs = preprocess(batch_xs,layer)
                # batch_x = np.array([t.numpy() for t in batch_xs])
                # optimizer.zero_grad()  # 梯度清零                
                labels = batch_y.copy()
 
                tempdata = np.reshape(batch_x,(batch_size, 1, 224, 224))
                batch_xx = torch.tensor(tempdata, dtype=torch.float)
                if use_gpu==True:
                    # batch_xx = batch_xx.to(torch_device)
                    batch_xx,labels = Variable(torch.tensor(batch_xx).cuda()), Variable(torch.tensor(labels).cuda())
                else:
                    batch_xx,labels = Variable(batch_xx), Variable(labels)
                optimizer.zero_grad()
                output = net(batch_xx)
                if netname=='GoogleNet':
                    if len(output)==3:
                        output = output.logits
                _,pred = torch.max(output.data, 1)
                # loss = criterion(output, onehotLab(labels, False))
                loss = criterion(output, labels)
                loss = loss.requires_grad_()
                loss.backward()
                optimizer.step()                
                running_loss += loss.data
                # running_loss += loss.item()
                running_correct += torch.sum(pred == labels)      
                if running_correct.item()/(batch_size*batch) > 0:
                    print("Batch {}, Train Loss:{:.6f}, Train ACC:{:.4f}".format(
                    batch, running_loss/(batch_size*batch), running_correct.item()/(batch_size*batch)))
                    # print('预测标签：{}, 真实标签：{}'.format(pred, labels))
                maxacc.append(running_correct.item()/(batch_size*batch))
                Accuracy_list.append(running_correct.item()/(batch_size*batch))
                Loss_list.append(running_loss/(batch_size*batch))
                # val_acc,val_loss = val_train(net,netname,criterion,batch_size=27,use_gpu=True)
                # val_Accuracy_list.append(val_acc)
                # val_Loss_list.append(val_loss)
        time_end = time.time()
        print('totally cost',time_end-time_start)
        #保存网络结构
        torch.save(net,os.path.join('model',netname+'_'+'net.pkl'))        
        print('预测标签：{}, 真实标签：{}'.format(pred, labels))
        y1 = Accuracy_list
        y2 = Loss_list
        # v1 = val_Accuracy_list
        # v2 = val_Loss_list
        Allacc.append(y1)
        Alllos.append(y2)
        # val_Allacc.append(v1)
        # val_Alllos.append(v2)
        val_acc,val_loss = val_train(net,netname,criterion,batch_size=27,use_gpu=True)
        test_acc,test_labels,test_outpres,prelabels = test_train(net,netname,batch_size=27,use_gpu=True)
        test_labels, test_outpres = [np.array(test_labels).ravel(), np.reshape(test_outpres,[2700,27])]
        test_all_labels.append(test_labels)
        test_labels = label_binarize(test_labels, classes=[0, 1, 2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26])
        test_all_label.append(test_labels)
        test_Accuracy_list.append(test_acc)        
        test_all_pres.append(test_outpres)
        Allprelabels.append(prelabels)
        print('val_acc:',val_acc)
        print('test_acc:',test_acc)
    pltROC(netlist, test_all_label, test_all_pres)
    np.save('testlabels',test_all_labels) # 保存为.npy格式
    np.save('testprelabels',Allprelabels) # 保存为.npy格式
    # print('testlabels:',test_all_labels)
    # print('testprelabels:',Allprelabels)
    
    ###保存训练集训练曲线
    fig = plt.figure()
    for i in range(len(netlist)):
        plt.plot(range(0,len(Allacc[i])), Allacc[i],label=netlist[i])        
        plt.legend()
    plt.xlabel('Accuracy vs. iters')
    plt.ylabel('Accuracy')
    plt.savefig(os.path.join('result_n','train_'+"accuracy.jpg"))
    fig = plt.figure()
    # bax = brokenaxes(ylims=((-0.001, .04), (.06, .07)), hspace=.05, despine=False)
    # for i in range(len(netlist)):
    #     bax.plot(range(0,len(Alllos[i])), Alllos[i], label=netlist[i])
    #     bax.legend() 
    # bax.set_xlabel('Loss vs. iters')
    # bax.set_ylabel('Loss')     
    # plt.savefig(os.path.join('result','train_'+"loss.jpg"))
    for i in range(len(netlist)):
        plt.plot(range(0,len(Alllos[i])), Alllos[i],label=netlist[i])        
        plt.legend()
    plt.xlabel('Loss vs. iters')
    plt.ylabel('Loss')     
    plt.savefig(os.path.join('result_n','train_'+"loss.jpg"))
    # ###保存验证集曲线
    # fig = plt.figure()
    # for i in range(len(netlist)):
    #     plt.plot(range(0,len(val_Allacc[i])), val_Allacc[i],label=netlist[i])        
    #     plt.legend()
    # plt.xlabel('Accuracy vs. iters')
    # plt.ylabel('Accuracy')
    # plt.savefig(os.path.join('result','val_'+"accuracy.jpg"))
    # fig = plt.figure()
    # bax = brokenaxes(ylims=((-0.001, .04), (.06, .07)), hspace=.05, despine=False)
    # for i in range(len(netlist)):
    #     bax.plot(range(0,len(val_Alllos[i])), val_Alllos[i], label=netlist[i])
    #     bax.legend() 
    # bax.set_xlabel('Loss vs. iters')
    # bax.set_ylabel('Loss')     
    # plt.savefig(os.path.join('result','val_'+"loss.jpg"))
    ###保存测试集曲线    
    # for netname in netlist:
    #     test_acc,test_labels,test_outpres = test_train(netname,batch_size=27,use_gpu=True)
    #     test_Accuracy_list.append(test_acc)
    #     test_all_labels.append(test_labels)
    #     test_all_pres.append(test_outpres)
    # pltROC(netlist, test_all_labels, test_all_pres)


def val_train(net,netname,criterion,batch_size=27,use_gpu=True):
    ##验证集训练
    val_batch = 0
    val_index_in_epoch = 0
    # val_Accuracy_list = []
    # val_Loss_list = []
    val_running_loss = 0.0
    val_running_correct = 0
    for val_iters in range(100):
        val_batch += 1
        val_batch_x, val_batch_y, val_index_in_epoch = _next_batch(batch_size, val_index_in_epoch)
        # for step, (inputs, labels) in enumerate(trainset_loader):
        # batch_xs = preprocess(batch_xs,layer)
        # batch_x = np.array([t.numpy() for t in batch_xs])
        # optimizer.zero_grad()  # 梯度清零                
        val_labels = val_batch_y.copy() 

        val_tempdata = np.reshape(val_batch_x,(batch_size, 1, 224, 224))
        val_batch_xx = torch.tensor(val_tempdata, dtype=torch.float)
        if use_gpu==True:
            # batch_xx = batch_xx.to(torch_device)
            val_batch_xx,val_labels = Variable(torch.tensor(val_batch_xx).cuda()), Variable(torch.tensor(val_labels).cuda())
            # net = net.cuda()
        else:
            val_batch_xx,val_labels = Variable(val_batch_xx), Variable(val_labels)
            net = net.copy()
        net.eval()
        val_output = net(val_batch_xx)
        if netname=='GoogleNet':
            if len(val_output)==3:
                val_output = val_output.logits
        _,val_pred = torch.max(val_output.data, 1)
        val_loss = criterion(val_output, val_labels)
        # loss = loss.requires_grad_()
        # loss.backward()
        # optimizer.step()                
        val_running_loss += val_loss.data
        # running_loss += loss.item()
        val_running_correct += torch.sum(val_pred == val_labels)      
        # if val_running_correct.item()/(batch_size*val_batch) > 0:
        #     print("Batch {}, Train Loss:{:.6f}, Train ACC:{:.4f}".format(
        #     val_batch, val_running_loss/(batch_size*val_batch), val_running_correct.item()/(batch_size*val_batch)))
        # val_Accuracy_list.append(running_correct.item()/(batch_size*batch))
        # val_Loss_list.append(running_loss/(batch_size*batch))
    return val_running_correct.item()/(batch_size*val_batch), val_running_loss/(batch_size*val_batch)

def test_train(net,netname,batch_size=27,use_gpu=True):
    ##验证集训练
    #2)打乱数据
    test_batch = 0
    test_index_in_epoch = 0
    test_running_loss = 0.0
    test_running_correct = 0
    labels = []
    outpres = []
    prelabels = []
    net.eval()
    with torch.no_grad():
        for test_iters in range(100):
            test_batch += 1
            test_batch_x, test_batch_y, test_index_in_epoch = _next_batch(batch_size, test_index_in_epoch)
            # for step, (inputs, labels) in enumerate(trainset_loader):
            # batch_xs = preprocess(batch_xs,layer)
            # batch_x = np.array([t.numpy() for t in batch_xs])
            # optimizer.zero_grad()  # 梯度清零                
            test_labels = test_batch_y.copy() 
            test_tempdata = np.reshape(test_batch_x,(batch_size, 1, 224, 224))
            test_batch_xx = torch.tensor(test_tempdata, dtype=torch.float)
            if use_gpu==True:
                # batch_xx = batch_xx.to(torch_device)
                test_batch_xx,test_labels = Variable(torch.tensor(test_batch_xx).cuda()), Variable(torch.tensor(test_labels).cuda())
                # net = torch.load(os.path.join('model', netname+'_'+'net.pkl'))
                # net = net.cuda()
            else:
                test_batch_xx,test_labels = Variable(test_batch_xx), Variable(test_labels)
                # net = torch.load(os.path.join('model', netname+'_'+'net.pkl'))        
            test_output = net(test_batch_xx)
            if netname=='GoogleNet':
                if len(test_output)==3:
                    test_output = test_output.logits
            _,test_pred = torch.max(test_output.data, 1)
            test_running_correct += torch.sum(test_pred == test_labels)      
            if test_running_correct.item()/(batch_size*test_batch) > 0:
                print("Batch {}, Train ACC:{:.4f}".format(
                test_batch, test_running_correct.item()/(batch_size*test_batch)))
            labels.append(test_labels.cpu().numpy())
            outpres.append(test_output.detach().cpu().numpy())
            prelabels.append(test_pred.cpu().numpy)
    return test_running_correct.item()/(batch_size*test_batch), labels,outpres,prelabels

if __name__ == '__main__':
    net = train()
