import numpy as np
import scipy.sparse
import sklearn.metrics
import torch
import scipy.sparse as sp

def adjacency(labels):
    '''
    Return adjacency matrix
    :param labels:
    :return: w:adjacency matrix
    '''
    V = []
    I = []
    J = []
    for templ,dl in enumerate(labels):
        for tempr,dr in enumerate(labels):
            if dl==dr:
                V.append(1)
                I.append(dl)
                J.append(dr)
    adj = scipy.sparse.coo_matrix((V, (I, J)), shape=(len(labels), len(labels)))

    # build symmetric adjacency matrix
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)

    adj = normalize(adj + sp.eye(adj.shape[0]))

    adj = sparse_mx_to_torch_sparse_tensor(adj)
    return adj

def normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx
def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)

