import numpy as np
import math
import matplotlib.pyplot as plt
def unit_circle(mat1,r,cx,cy):
    '''
    生成圆形
    r:半径
    cx,cy分别是中心点坐标
    '''
    def distance(x1, y1, x2, y2):
        return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
    rx , ry = int(cx), int(cy)
    for row in range(cx-r,cx+r):
        for col in range(cy-r,cy+r):
            dist = distance(rx, ry, row, col)
            # print((row,col),dist)
            if abs(dist) > r-1 and abs(dist) < r+1:
                mat1[row, col] = 1
    finalmat = mat1
    return finalmat

def points(p, leni):
    # 返回p,leni对应的半径和圆心列表
    return [(p[0]-leni//2, p[1]-leni//2),(p[0]-leni//2, p[1]+leni//2),(p[0]+leni//2, p[1]-leni//2),(p[0]+leni//2, p[1]+leni//2)],int(leni//2)
def fracircle(mat1,p,leni):
    '''
    生成图形大小
    '''
    mat1 = unit_circle(mat1, int(leni // 2), p[0], p[1])
    certen, r = points(p, leni)[0],int(points(p, leni)[1])
    for i in range(4):
        cx,cy = int(certen[i][0]),int(certen[i][1])
        if leni > 2:
            mat1 = fracircle(mat1, (cx, cy),r)
    # if leni > 2:
    #     mat1 = fracircle(mat1,p,leni)
    leni /= 2
    leni = int(leni)

    return mat1




if __name__ == "__main__":
    d = 224
    mat1 = np.zeros((d,d))
    mat1 = fracircle(mat1, (d//2,d//2), d//2)
    plt.figure(figsize=(1, 1))  # 设置子图大小
    plt.subplot(1, 1, 1)  # 添加画布，先设置第一个子图的内容
    plt.imshow(mat1)
    plt.title('原始信号')
