import numpy as np
import matplotlib.pyplot as plt
from math import atan2,pi
d = 224
trimat = np.zeros((d,d))
for i in range(d):
    for j in range(d):
        if atan2(j,i)<pi/3 and atan2(0-j,d-i)>-pi/3 and j>34:
            trimat[i,j] = 1

plt.figure(figsize=(8,8))#设置子图大小
plt.subplot(2,2,1) #添加画布，先设置第一个子图的内容
plt.imshow(trimat)
plt.title('原始信号')