import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft,ifft
from matplotlib.pylab import mpl
mpl.rcParams['font.sans-serif'] = ['SimHei']   #显示中文
mpl.rcParams['axes.unicode_minus']=False       #显示负号
N = 224 #采样点选择256
x = np.linspace(-10, 10, N)
y = np.linspace(-10, 10, N)
X,Y = np.meshgrid(x,y) #生成一个矩阵，并填充数据.
Z = np.sin(0.5 * np.pi * Y)

Z_fft2 = np.fft.fft2(Z)  #二维傅里叶变换
Z_fft2_A = abs(np.fft.fftshift(Z_fft2)) #将低频移动到中心
Z_fft2 = np.fft.fft2(Z)  #二维傅里叶变换
Z_fft2_A = abs(np.fft.fftshift(Z_fft2)) #将低频移动到中心

plt.figure(figsize=(8,8))#设置子图大小
plt.subplot(2,2,1) #添加画布，先设置第一个子图的内容
plt.imshow(Z)
plt.title('原始信号')

plt.subplot(2,2,2)#设置第2个子图的内容
plt.imshow(abs(Z_fft2))
plt.title('二维傅里叶变换后')

plt.subplot(2,2,3)#设置第3个子图的内容
plt.imshow(Z_fft2_A) #将低频移动到图像中心的显示出来
plt.title('低频转移中心')

plt.subplot(2,2,4)#设置第4个子图的内容
plt.plot(Z_fft2_A[128,:])# 等于plt.plot(Z_fft2_sh[128,1:255])
plt.title('x = 128')
plt.show()
