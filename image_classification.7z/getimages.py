import cleardata #无纹理
import shapedatagauss#条形纹理
import shapfracdata #双纹理
import numpy as np
from PIL import Image


if __name__ == "__main__":

    #尺度变化,相同纹理
    #噪声图像
    fractal2 = np.load("circle.npy")  # 圆
    mask = np.random.normal(size=(224, 224), scale=0.2, loc=0)
    for r in [80, 60, 40]:
        if r == 80:
            circle_b = cleardata.unit_circle(224, r, mask)
        elif r == 60:
            circle_m = shapedatagauss.unit_circle(224, r, mask, 3)
        elif r == 40:
            circle_s = shapfracdata.unit_circle(224, r, mask,4)
            circle_s = np.multiply(fractal2, circle_s)
    Image.fromarray((circle_b * 255).astype('uint8'), mode='L').convert('RGB').save('noisedifcircle_b.png')
    Image.fromarray((circle_m * 255).astype('uint8'), mode='L').convert('RGB').save('noisedifcircle_m.png')
    Image.fromarray((circle_s * 255).astype('uint8'), mode='L').convert('RGB').save('noisedifcircle_s.png')
