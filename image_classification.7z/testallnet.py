
#  Pytorch 0.4.0 VGG16实现cifar10分类.  
# @Time: 2018/6/23
# @Author: xfLi
'''
本程序实现生成测试矩阵（图像），来测试网络的可行性
测试数据尺寸：224*224
bathsize:20
输入图像只含有形状数据和噪声数据
'''
#前三行解决自定义包报错问题

import sys,os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # __file__获取执行文件相对路径，整行为取上一级的上一级目录
sys.path.append(BASE_DIR)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import torch
import torch.nn as nn
import numpy as np
# from tensorboardX import SummaryWriter
# from timeplot import epochplt
import cv2
from torchvision import datasets,transforms, models
import torchvision
import modelnet
# from plugin.processplugin import Generations
from torch.autograd import Variable
import random
from cleardata import *
import matplotlib.pyplot as plt
from brokenaxes import brokenaxes
from sklearn.metrics import roc_curve, auc
from sklearn.preprocessing import label_binarize
scale = 0
loc   = 1
mask = np.random.normal(size=(224,224), scale=scale, loc=loc) #loc表示均值，scale表示方差，size表示输出的size
def _next_batch(train_labels, batch_size, index_in_epoch, mask):
    start = index_in_epoch
    index_in_epoch += batch_size
    num_examples = train_labels.__len__()
    train_images = []
    rotIdex = False
    # when all trainig data have been already used, it is reorder randomly
    if index_in_epoch > num_examples:
        start = 0
        index_in_epoch = batch_size
        assert batch_size <= num_examples
    end = index_in_epoch
    labels = train_labels[start:end]
    newlabels = []
    for i in labels:
        if i==0:
            img = unit_circle(224, 80, mask)
        elif i==1:
            img = unit_square(224,80,mask)
        elif i==2:
            img = unit_triangle(224,100,mask)
        train_images.append(img)
        newlabels.append(i)
        if rotIdex:
            img = unit_rot(img)
            train_images.append(img)
            newlabels.append(i)
    return train_images, newlabels, index_in_epoch

def test_train(netname,mask,batch_size=30,use_gpu=True):
    ##验证集训练
    #1）生成验证集
    test_y0 = np.zeros(300,dtype=np.int)
    test_y1 = np.ones(300, dtype=np.int)
    test_y2 = np.ones(300, dtype=np.int)*2
    test_y_label = np.concatenate((test_y0,test_y1,test_y2),axis=0)
    #2)打乱数据
    test_num = random.randint(1,2000)
    random.seed(test_num)
    random.shuffle(test_y_label)
    test_batch = 0
    test_index_in_epoch = 0
    newprelabels = []
    newtrulabels = []
    for test_iters in range(int(test_y_label.__len__()/batch_size)):
        test_batch += 1
        test_batch_x, test_batch_y, test_index_in_epoch = _next_batch(test_y_label, batch_size, test_index_in_epoch,mask)
        # for step, (inputs, labels) in enumerate(trainset_loader):
        # batch_xs = preprocess(batch_xs,layer)
        # batch_x = np.array([t.numpy() for t in batch_xs])
        # optimizer.zero_grad()  # 梯度清零                
        test_labels = test_batch_y.copy() 
        test_tempdata = np.reshape(test_batch_x,(batch_size, 1, 224, 224))
        test_batch_xx = torch.tensor(test_tempdata, dtype=torch.float)
        if use_gpu==True:
            # batch_xx = batch_xx.to(torch_device)
            test_batch_xx,test_labels = Variable(torch.tensor(test_batch_xx).cuda()), Variable(torch.tensor(test_labels).cuda())
            net = torch.load(os.path.join('/media/liqiang/windata/project/classification/plugin/model',netname+'_'+'net.pkl'))
            net = net.cuda()
        else:
            test_batch_xx,test_labels = Variable(test_batch_xx), Variable(test_labels)
            net = torch.load(os.path.join('/media/liqiang/windata/project/classification/plugin/model',netname+'_'+'net.pkl'))
        net.eval()
        test_output = net(test_batch_xx)
        # _,test_pred = torch.max(test_output.data, 1)
        newprelabels.append(test_output.detach().cpu().numpy())
        newtrulabels.append(test_labels.cpu().numpy())
    return np.array(newtrulabels).ravel(), np.reshape(newprelabels,[900,3])
def pltroc_auc(y_test,y_score,n_classes,name):
    # Compute ROC curve and ROC area for each class
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    index = min(roc_auc, key=roc_auc.get)

    # Compute micro-average ROC curve and ROC area
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    # plt.figure()
    lw = 2
    plt.plot(fpr[index], tpr[index], color='darkorange',
            lw=lw, label=name+'ROC'+'(area = %0.4f)' % roc_auc[index])
    # plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    # plt.xlim([0.0, 1.0])
    # plt.ylim([0.0, 1.05])
    # plt.xlabel('False Positive Rate')
    # plt.ylabel('True Positive Rate')
    # plt.title('Receiver operating characteristic example')
    # plt.legend(loc="lower right")
    # plt.savefig(os.path.join('/media/liqiang/windata/project/classification/plugin/ROC_AUC_FIG',name+"_roc.jpg"))
    # plt.show()
    # plt.close()

if __name__ == "__main__":
    netlist = ['MobileNet','ResNet','ShuffleNet','SqueezeNet','AlexNet','DenseNet','GoogleNet','MnasNet','VggNet']
    experient = ['ex1','ex2','ex3','ex4','ex5','ex6','ex7','ex8','ex9','ex10','ex11']
    for netname in netlist:
        for exp in experient:
            test_labels, test_pred = test_train(exp+netname, mask)
            test_labels = label_binarize(test_labels, classes=[0, 1, 2])
            # test_pred = label_binarize(test_pred, classes=[0, 1, 2])
            pltroc_auc(test_labels,test_pred,3,exp+netname)